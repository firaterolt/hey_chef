-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 01 Ara 2022, 19:22:52
-- Sunucu sürümü: 5.7.36
-- PHP Sürümü: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `test`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `links` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `links`, `date`) VALUES
(1, 'http://localhost/linkpayment/cenkkaanbolukbas@hotmail.com/Bolukbas/cenkkaanbolukbas@hotmail.com/2022/12/01/{3B8D7C67-A825-47EB-9A3D-D0804078CFD6}', '2022-12-01'),
(2, 'http://localhost/linkpayment/deneme@deneme.com/Deneme2/deneme@deneme.com/2022/12/01/{9C1E481A-844D-4B44-AD85-FC8430B02D96}', '2022-12-01'),
(3, 'http://localhost/linkpayment/Deniyorum@deniyorum.com/Denedim/Deniyorum@deniyorum.com/2022/12/01/{5AE88F0A-9C8F-40CA-878C-7D5C597A697D}', '2022-12-01'),
(4, 'http://localhost/linkpayment/test.mail@testmaili.com/testsurname/test.mail@testmaili.com/01.12.2022/{030AD422-6230-4BBF-A7BA-0CBDA26820F1}', '2001-12-20');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `price`, `description`, `unit`, `name`, `surname`) VALUES
(17, 'cenkkaanbolukbas@hotmail.com', '05522102906', '14725', 'Deneme', 'DOLAR', 'Cenk Kaan', 'Bolukbas'),
(18, 'deneme@deneme.com', '05505050505', '1234578', 'Denemee', 'DOLAR', 'Deneme', 'Deneme2'),
(19, 'Deniyorum@deniyorum.com', '0551515151', '2354789', 'Denedim', 'EURO', 'Deniyorum ', 'Denedim'),
(20, 'test.mail@testmaili.com', '051651651', '1515161651', 'test', 'TRY', 'test', 'testsurname');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
