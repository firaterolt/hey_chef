<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
</head>

<body>

<?php
$con = mysqli_connect("localhost", "root", "", "test");
// Check connection
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$users = mysqli_query($con, "SELECT * FROM users");
$admin = mysqli_query($con, "SELECT * FROM admin");
$query2 = mysqli_query($con, "SELECT users.id,admin.id FROM users,admin INNER JOIN admin ON users.id=admin.id");
echo "<table border='1'>
<tr>
<th>name</th>
<th>surname</th>
<th>email</th>
<th>phone</th>
<th>price</th>
<th>description</th>
</tr>";

while ($row = mysqli_fetch_array($users)) {
    echo "<tr>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['surname'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "<td>" . $row['phone'] . "</td>";
    echo "<td>" . $row['price'] . "</td>";
    echo "<td>" . $row['description'] . "</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($con);
?>

</body>
</html>