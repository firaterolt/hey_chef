<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,500|Open+Sans:400,700">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/docs.theme.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>

    <title>Main</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f3f3f3;
            background-image: url("images/back.png");
        }

        button,
        input {
            border: 0;
            background: 0;
            margin: 0;
            padding: 0;
        }

        p,
        span,
        a,
        div,
        input {
            font-family: "Open Sans", sans-serif;
            font-size: 12px;
        }

        h1,
        h2,
        h3,
        h4 {
            font-family: "Montserrat", sans-serif;
        }

        a {
            text-decoration: none;
            cursor: pointer;
            color: black;
        }

        ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        header .container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 1000px;
            margin: 0px auto;
            height: 100%;
            transition: 0.3s;
        }

        header .container .logo {
            position: relative;
        }

        header .container .logo span:nth-of-type(1) {
            font-family: "Montserrat", sans-serif;
            font-size: 25px;
            font-weight: 600;
        }

        header .container .mobile_nav {
            margin: 1px 10px 0;
            display: none;
        }

        header .container .mobile_nav .burger {
            width: 19px;
            height: 19px;
            position: relative;
            overflow: hidden;
        }

        header .container .mobile_nav .burger:active .top,
        header .container .mobile_nav .burger:focus .top,
        header .container .mobile_nav .burger:hover .top {
            width: 60% !important;
        }

        header .container .mobile_nav .burger:active .middle,
        header .container .mobile_nav .burger:focus .middle,
        header .container .mobile_nav .burger:hover .middle {
            width: 70% !important;
        }

        header .container .mobile_nav .burger:active .bottom,
        header .container .mobile_nav .burger:focus .bottom,
        header .container .mobile_nav .burger:hover .bottom {
            width: 80% !important;
        }

        header .container .mobile_nav .burger .mobile_nav__label {
            margin: -10px 5px;
            width: 135px;
            position: absolute;
        }

        header .container .mobile_nav .burger .stripe {
            height: 4px;
            background: black;
            position: absolute;
            transition: 0.2s ease;
        }

        header .container .mobile_nav .burger .top {
            right: 0;
            top: 0;
            width: 100%;
        }

        header .container .mobile_nav .burger .middle {
            left: 0;
            top: 0;
            margin: 6.9px 0;
            width: 60%;
        }

        header .container .mobile_nav .burger .bottom {
            right: 0;
            top: 0;
            margin: 14px 0;
            width: 80%;
        }

        header .container .head_nav {
            margin: 0 50px;
            width: 100%;
        }

        header .container .head_nav ul {
            text-align: center;
        }

        header .container .head_nav ul .visited a:after {
            content: "";
            position: absolute;
            width: 100%;
            height: 4px;
            background: black;
            margin: 15.5px 0;
            right: 0;
        }

        header .container .head_nav ul li {
            display: inline-block;
            margin: 0 15px;
        }

        header .container .head_nav ul li a {
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.8px;
            position: relative;
        }

        header .container .head_nav ul li a:after {
            content: "";
            position: absolute;
            width: 0%;
            height: 4px;
            background: black;
            transition: 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            margin: 15.5px 0;
            right: 0;
        }

        header .container .head_nav ul li a:hover:after {
            width: 100%;
            left: 0;
        }

        header .container .icons {
            min-width: 85px;
        }

        header .container .icons a {
            margin: 0 5px 0;
            display: block;
            height: 27px;
            width: 27px;
        }

        header .container .icons a:hover svg {
            fill: #4c4c4c !important;
        }

        header .container .icons a:active svg {
            fill: #F40303 !important;
        }

        header .container .icons .block {
            display: inline-block;
        }

        header .container .icons svg {
            display: block;
            transition: 0.2s ease;
        }

        header {
            background: #FFF;
            height: 100px;
            position: relative;
        }

        .mobile_menu {
            z-index: 999999;
            background: black;
            width: 90%;
            height: 420px;
            top: 65px;
            left: 0;
            margin: 10px 20px;
            border-radius: 4px;
            position: absolute;
            display: none;
        }

        .mobile_menu:before {
            z-index: 999999;
            content: "";
            position: absolute;
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 0 15px 15px 15px;
            border-color: transparent transparent #F40303 transparent;
            margin: -10px 35px;
        }

        .mobile_menu nav {
            padding: 50px;
        }

        .mobile_menu nav ul .slide a {
            opacity: 1;
            position: relative;
            animation: hidecolor 0.8s ease;
        }

        .mobile_menu nav ul .slide a:before {
            content: "";
            position: absolute;
            background: #F40303;
            width: 0%;
            height: 35px;
            animation: slide 0.8s ease;
        }

        .mobile_menu nav ul li {
            margin: 30px 0px;
        }

        .mobile_menu nav ul li a {
            font-family: "Montserrat", sans-serif;
            opacity: 0;
            font-size: 25px;
            font-weight: 600;
            padding: 10px 0px;
            color: white;
        }

        @media only screen and (max-width: 1100px) {
            .mobile_menu {
                display: none;
            }

            header .container {
                width: 700px;
            }
        }

        @media only screen and (max-width: 800px) {
            .mobile_menu {
                display: none;
            }

            header {
                padding: 0 50px;
                height: 60px;
            }

            header .container {
                width: 100%;
            }

            header .container .icons a {
                width: 25px;
                height: 25px;
            }

            header .head_nav {
                display: none;
            }

            header .logo {
                width: 100%;
                text-align: center;
            }

            header .mobile_nav {
                cursor: pointer;
                display: block !important;
            }

            header .mobile_nav .stripe {
                width: 100% !important;
            }
        }

        @media only screen and (max-width: 500px) {
            header {
                padding: 0 20px;
            }

            header .logo span {
                font-size: 20px !important;
            }

            .mobile_menu {
                height: 295px;
            }

            .mobile_menu:before {
                margin: -10px 5px;
            }

            .mobile_menu nav {
                padding: 30px 50px;
            }

            .mobile_menu nav ul li {
                margin: 20px 0px;
            }

            .mobile_menu nav ul li a {
                font-size: 18px;
            }

            .mobile_menu nav ul li a:before {
                height: 23px !important;
            }
        }

        @keyframes slide {
            0% {
                width: 0;
                padding: 0px 10px;
                margin: 0px -5px;
            }

            80% {
                width: 105%;
                padding: 0px 10px;
                margin: 0px -5px;
            }

            100% {
                width: 0;
                padding: 0 0;
            }
        }

        @keyframes hidecolor {
            0% {
                color: black;
            }

            75% {
                color: black;
            }

            100% {
                color: white;
            }
        }

        .mobile-logo {
            max-width: 60px;
            margin-left: 125px;
        }

        .i-1 {
            margin-left: 85px;
        }

        .i-2 {
            margin-top: 10px;
            margin-left: 35px;
        }

        .yemek-title {
            font-weight: bold;
            font-size: 15px;
            color: #4c4c4c;
            font-family: Poppins;
        }

        .yemek-desc {
            font-weight: normal;
            font-size: 9px;
            color: #4c4c4c;
            font-family: Poppins;
        }

        .yemek-alt {
            border: 15px solid white;
            border-bottom-right-radius: 25px;
            border-bottom-left-radius: 25px;
            background-color: white;

        }

        .yemek-alt-desc {
            display: flex;
            flex-wrap: nowrap;
        }

        .yemek-alt-desc img {
            max-width: 50px;
            max-height: 17px;
            padding-left: 15px;
            margin-top: 15px;
        }

        .my {
            font-size: 15px;
            font-family: Poppins;
            font-weight: normal;
            text-align: center;
            margin-top: 15px;
        }

        .title {
            text-align: center;
            color: red;
            text-decoration: underline;
            font-weight: bold;
            margin-top: 25px;
            font-size: 30px;
            font-family: Poppins;
        }

        .secondTitle {
            text-align: center;
            font-weight: bold;
            margin-top: 25px;
            font-size: 15px;
            font-family: Poppins;
        }

        .thirdTitle {
            color: white;
            text-align: center;
            margin-top: 25px;
            font-size: 20px;
            font-family: Poppins;
        }

        .fourthTitle {
            color: white;
            text-align: center;
            font-weight: bold;
            margin-top: 25px;
            font-size: 25px;
            font-family: Poppins;
        }

        .tarifText {
            text-align: center;
            margin-top: 25px;
            font-size: 10px;
            font-family: Poppins;
            padding-left: 25px;
            padding-right: 25px;
        }

        .goContainer {
            background-color: red;
            border: 1px solid red;
            color: white;
            width: 200%;
            margin-left: -50%;
            height: 350px;
            border-radius: 50%;
        }

        .fontFamily {
            font-family: Poppins;
        }

        .logo {
            max-width: 200px;
        }

        .mt--4 {
            margin-top: -2rem !important;
        }

        .highlight {
            color: #F58426;
        }

        .sliderContainer {
            margin: 5% 0 0 3rem;
            max-width: 55%;
        }

        .sliderImg {
            min-width: 1000px;
            border: 1px solid white;
            border-radius: 35px;
        }

        .slideInfo {
            position: relative;
            border: 1px solid white;
            border-radius: 0px 0px 35px 35px;
            margin-top: 60px;
            background-color: white;
            margin-left: 2px;
            text-align: center;
        }

        .slideInfo p {
            font-family: Poppins;
            opacity: 2;
            color: black;
            font-size: 15px;
            margin-left: 15px;
        }

        .owl-nav button {
            position: absolute;
            top: 50%;
            background-color: #000;
            color: #fff;
            margin: 0;
            transition: all 0.3s ease-in-out;
        }

        .owl-nav button.owl-prev {
            left: 0;
        }

        .owl-nav button.owl-next {
            right: 0;
        }

        .owl-dots {
            text-align: center;
            padding-top: 15px;
        }

        .owl-dots button.owl-dot {
            width: 55px;
            height: 15px;
            border-radius: 10%;
            display: inline-block;
            background: #313131;
            margin: 0 3px;
        }

        .owl-dots button.owl-dot.active {
            background-color: red;
        }

        .owl-dots button.owl-dot:focus {
            outline: none;
        }

        .owl-nav button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.38) !important;
        }

        span {
            font-size: 70px;
            position: relative;
            top: -5px;
        }

        .owl-nav button:focus {
            outline: none;
        }
    </style>
</head>
<header>
    <div class='container'>
        <div class='mobile_nav'>
            <button class='burger' title='Open and close menu'>
                <img class="img-fluid" src="images/menu.png">
            </button>
        </div>
        <div class='mobile_menu'>
            <nav>
                <ul>
                    <li class='visited'>
                        <a href='/home'>Home</a>
                    </li>
                    <li>
                        <a href='/toplist'>Recipes</a>
                    </li>
                    <li>
                        <a href='/forum'>Forum</a>
                    </li>
                    <li>
                        <a href='/blog'>Blog</a>
                    </li>
                    <li>
                        <a href='/contact'>Contact</a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class='logo'>
            <div class="img-fluid">
                <img class="mobile-logo" src="images/logo.png">
            </div>
        </div>
        <nav class='head_nav'>
            <ul>
                <li class='visited'>
                    <a href='/home'>Home</a>
                </li>
                <li>
                    <a href='/toplist'>Recipes</a>
                </li>
                <li>
                    <a href='/forum'>Forum</a>
                </li>
                <li>
                    <a href='/blog'>Blog</a>
                </li>
                <li>
                    <a href='/contact'>Kontakt</a>
                </li>
            </ul>
        </nav>
        <div class='icons'>
            <div class='block'>
                <a class='notification' href='?notifiacitons' title='Notifications'>
                    <img class="img-fluid i-1" src="images/Subtract.png">
                </a>
            </div>
        </div>
        <div class='icons'>
            <div class='block'>
                <a class='user_profile' href='?user_profile' title='User profile'>
                    <img class="img-fluid i-2" src="images/arama.png">
                </a>
            </div>
        </div>
    </div>
</header>

<body>
    <section class="flex-row ml-5">
        <div class="sliderContainer">
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Makarnanızı süzgeç yardımı ile süzün. Sakın soğuk suyun altında tutmayın.Tadı kaçar benden söylemesi!</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Pişen makarnayı soğuk sudan geçirmek, makarnanın sos tutuşunu aynı zamanda lezzetini azaltır.</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Uzun ve yuvarlak makarnalarda salçalı ve domatesli sosları tercih edebilirsiniz.</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Sos tutma özelliğine sahip olan burgu tarzı diğer makarnalarda ise sebzeli ve akışkan sosları makarnanıza ekleyebilirsiniz.</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Pişen makarnayı soğuk sudan geçirmek, makarnanın sos tutuşunu aynı zamanda lezzetini azaltır.</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Makarnanızı süzgeç yardımı ile süzün. Sakın soğuk suyun altında tutmayın.Tadı kaçar benden söylemesi!</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Pişen makarnayı soğuk sudan geçirmek, makarnanın sos tutuşunu aynı zamanda lezzetini azaltır.</p>
                    </div>
                </div>
                <div class="item">
                    <div class="slideInfo">
                        <p class="mt-4">Sos tutma özelliğine sahip olan burgu tarzı diğer makarnalarda ise sebzeli ve akışkan sosları makarnanıza ekleyebilirsiniz.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <h2 class='secondTitle'>Tarif</h2>
    <p class='tarifText'>Penne’ye gelene kadar bizlerin düdük diye de bildiği kalın ve ince kesme makarnalar da var
        arada. Orta kısmı boş, uç kısımları küt ve yoğun makarna tadı içeren bu çeşitler şöyle dursun biz penne
        makarnayı tanıyalım. Oldukça havalı bir şekilde, İtalyanca "Penne Rigate" diye telaffuz edilen kahramanımız içi
        boş yapısı gereği kremalı, domatesli ayırt etmeden yutar gider tüm sosları.</p>

    <div class="goContainer">
        <p class="thirdTitle"> Malzemeler Hazırsa </p>
        <p class="fourthTitle"> Yemek Yapmaya Geçebiliriz ! </p>
    </div>

    <script>
        $(".mobile_nav").click(function () {
            var mm = $(".mobile_menu"),
                mn = $(".mobile_nav"),
                a = "active";

            if (mm.hasClass(a) && mn.hasClass(a)) {
                mm.removeClass(a).fadeOut(200);
                mn.removeClass(a);
                $(".mobile_menu li").each(function () {
                    $(this).removeClass("slide");
                });
            } else {
                mm.addClass(a).fadeIn(200);
                mn.addClass(a);
                $(".mobile_menu li").each(function (i) {
                    var t = $(this);
                    setTimeout(function () {
                        t.addClass("slide");
                    }, (i + 1) * 100);
                });
            }
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: true,
                        loop: false,
                        margin: 20
                    }
                }
            })
        })
    </script>
</body>

</html>