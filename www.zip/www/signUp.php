<?php
session_start();
include('config.php');
if (isset($_POST['create'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $cinsiyet = $_POST['cinsiyet'];
    
    $date = date("d.m.Y");
    $query = $connection->prepare("SELECT * FROM users WHERE email=:email");
    $query->bindParam("email", $email, PDO::PARAM_STR);
    $query->execute();

    if ($query->rowCount() == 0) {
        $query = $connection->prepare("INSERT INTO users(name,password,email,phone,cinsiyet) VALUES (:name,:password,:email,:phone, :cinsiyet)");
        $query->bindParam("name", $name, PDO::PARAM_STR);
        $query->bindParam("cinsiyet", $cinsiyet, PDO::PARAM_STR);
        $query->bindParam("password", $password, PDO::PARAM_STR);
        $query->bindParam("email", $email, PDO::PARAM_STR);
        $query->bindParam("phone", $phone, PDO::PARAM_STR);
        $result = $query->execute();
        if ($result) {
            echo '<p class="success">Your registration was successful!</p>';
            header("location: main.php");
        } else {
            echo '<p class="error">Something went wrong!</p>';
        }
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <title>Login 07</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css/style.css">

</head>

<body>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="wrap d-md-flex">
                        <div class="text-wrap p-4 p-lg-5 text-center d-flex align-items-center order-md-last">
                            <div class="text w-100">
                                <div class="img-fluid">
                                    <img src="images/logo.png">
                                </div>
                                <h2>Welcome to login</h2>
                                <p>Don't have an account?</p>
                                <a href="#" class="btn btn-white">Sign Up</a>
                            </div>
                        </div>
                        <div class="login-wrap p-4 p-lg-5">
                            <div class="d-flex">
                                <div class="w-100">
                                    <h3 class="mb-4">Login</h3>
                                </div>
                            </div>
                            <form method="post" action="" name="signin-form">
                                <div class="form-group mb-3">
                                    <label class="label">Email Address *</label>
                                    <input type="text" name="email" class="form-control" required />
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label" for="password">Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label">Name & Surname</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label">Phone Number</label>
                                    <input type="number" name="phone" class="form-control" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="label">cinsiyet</label>
                                    <input type="text" name="cinsiyet" class="form-control" required>
                                </div>
                                <div class="form-group">
                                        <button type="submit" class="form-control btn btn-primary submit px-3" name="create" value="create">Sign In</button>
                                </div>
                                <div class="d-flex">
                                    <div class="w-100">
                                        <p class="social-media d-flex justify-content-center">
                                            <a href="#"
                                                class="social-icon d-flex align-items-center justify-content-center"><span
                                                    class="fa fa-facebook"></span></a>
                                            <a href="#"
                                                class="social-icon d-flex align-items-center justify-content-center"><span
                                                    class="fa fa-twitter"></span></a>
                                            <a href="#"
                                                class="social-icon d-flex align-items-center justify-content-center"><span
                                                    class="fa fa-linkedin"></span></a>
                                            <a href="#"
                                                class="social-icon d-flex align-items-center justify-content-center"><span
                                                    class="fa fa-google"></span></a>
                                        </p>
                                    </div>
                                </div>
                                <div class="form-group d-md-flex">
                                    <div class="w-50 text-left">
                                        <label class="checkbox-wrap checkbox-primary mb-0">Remember Me
                                            <input type="checkbox" checked>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    
                                    <div class="w-50 text-md-right">
                                        <a href="#">Forgot Password</a>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>