import 'package:avatar_glow/avatar_glow.dart';
import 'package:circle_bottom_navigation_bar/circle_bottom_navigation_bar.dart';
import 'package:circle_bottom_navigation_bar/widgets/tab_data.dart';
import 'package:flutter/material.dart';

import 'package:speech_to_text/speech_to_text.dart' as stt;

class Specification extends StatefulWidget {
  Specification({Key? key}) : super(key: key);

  @override
  State<Specification> createState() => _SpecificationState();
}

class _SpecificationState extends State<Specification> {
  late stt.SpeechToText _speech;
  bool _isListening = false;
  String? _speakVal;
  double _confidence = 1.0;
  void _listen() async {
    if (_isListening == true) {
      bool available = await _speech.initialize(
        onStatus: (val) async {
          if (val == "done") {
            await setStep();
            _listen();
          } else {
            print("onStatus: " + val);
          }
        },
        onError: (val) {
          print('onError: $val');
          _listen();
        },
      );
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          localeId: "tr-TR",
          onResult: (val) => setState(() {
            _speakVal = val.recognizedWords;
            print(val.recognizedWords);
            if (val.hasConfidenceRating && val.confidence > 0) {
              _confidence = val.confidence;
            }
          }),
        );
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  int pageVal = 0;
  int defaultStep = 1;
  int currentPage = 0;

  Future setStep() async {
    List bolumler = [];
    List adimlar = [];
    for (var i = 0; i < data[1].length; i++) {
      bolumler.add("bölüm " + (i + 1).toString());
    }
    for (var i = 0; i < bolumler.length; i++) {
      if (_speakVal!.toLowerCase() == bolumler[i]) {
        setState(() {
          pageVal = 0;
          defaultStep = i + 1;
        });
      }
    }
    for (var i = 0; i < data[1][defaultStep].length; i++) {
      adimlar.add("adım " + (i + 1).toString());
    }

    for (var i = 0; i < adimlar.length; i++) {
      if (_speakVal!.toLowerCase() == adimlar[i]) {
        setState(() {
          pageVal = i;
        });
      }
    }
  }

  List data = [
    "Tavuklu çorba",
    {
      1: [
        {
          "desc": "ilk olarak hazır knor Tavuklu Çorbanın ağzını aç",
          "img": "https://i.ytimg.com/vi/MAANmOPpNkg/maxresdefault.jpg"
        },
        {
          "desc": "Ve suya dök 15 dakika karıştır",
          "img":
              "https://im.haberturk.com/2020/04/21/ver1587444948/2652945_810x458.jpg"
        },
        {
          "desc": "ilk olarak hazır knor Tavuklu Çorbanın ağzını aç",
          "img": "https://i.ytimg.com/vi/MAANmOPpNkg/maxresdefault.jpg"
        },
        {
          "desc": "Ve suya dök 15 dakika karıştır",
          "img":
              "https://im.haberturk.com/2020/04/21/ver1587444948/2652945_810x458.jpg"
        },
      ],
      2: [
        {
          "desc": "önce karıştır2",
          "img":
              "https://gcdn.bionluk.com/uploads/message/43d131dc-1b93-4166-a96b-33867576b014.png"
        },
        {
          "desc": "önce kaynat2",
          "img":
              "https://gcdn.bionluk.com/uploads/message/43d131dc-1b93-4166-a96b-33867576b014.png"
        },
      ],
      3: [
        {
          "desc": "önce karıştır3",
          "img":
              "https://gcdn.bionluk.com/uploads/message/43d131dc-1b93-4166-a96b-33867576b014.png"
        },
        {
          "desc": "önce kaynat3",
          "img":
              "https://gcdn.bionluk.com/uploads/message/43d131dc-1b93-4166-a96b-33867576b014.png"
        },
      ]
    }
  ];

  Widget StepButton(int index) {
    return GestureDetector(
      onTap: () {
        if (defaultStep != index) {
          setState(() {
            defaultStep = index;
            pageVal = 0;
          });
        }
      },
      child: Container(
        width: 50,
        padding: EdgeInsets.only(top: 5, bottom: 5),
        margin: EdgeInsets.only(right: 10),
        decoration: BoxDecoration(
            color: defaultStep == index
                ? Theme.of(context).primaryColor
                : Colors.grey.shade200,
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(5)),
        child: Center(
          child: Text(
            index.toString() + ".",
            style: TextStyle(
                color: defaultStep == index ? Colors.white : Colors.grey),
          ),
        ),
      ),
    );
  }

  Widget dotButton(int index, Color color) {
    return GestureDetector(
      onTap: () {
        setState(() {
          pageVal = index;
        });
      },
      child: Container(
        margin: EdgeInsets.only(right: 10, top: 10),
        width: 40,
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _speech = stt.SpeechToText();

    _listen();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CircleBottomNavigationBar(
        initialSelection: currentPage,
        circleColor: Theme.of(context).primaryColor,
        activeIconColor: Colors.white,
        inactiveIconColor: Colors.grey,
        tabs: [
          TabData(
            icon: Icons.person,
            // Optional
          ),
          TabData(icon: Icons.cookie),
          TabData(icon: Icons.home),
          TabData(icon: Icons.alarm),
        ],
        onTabChangedListener: (index) => setState(() => currentPage = index),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: 30,
                margin: EdgeInsets.only(top: 20, bottom: 20),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: data[1].length,
                  shrinkWrap: true,
                  itemBuilder: ((context, index) {
                    return Center(child: StepButton(1 + index));
                  }),
                ),
              ),
              Container(
                padding: EdgeInsets.only(bottom: 5),
                margin: EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: Colors.black)),
                ),
                child: Text(
                  data[0].toString(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20,
                    decorationThickness: 1,
                    wordSpacing: 5,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              Container(
                  margin: EdgeInsets.only(left: 10, bottom: 20),
                  height: 15,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemCount: data[1][defaultStep].length,
                    itemBuilder: ((context, i) {
                      return dotButton(
                          i,
                          i < pageVal
                              ? Colors.red.shade100
                              : pageVal == i
                                  ? Colors.red
                                  : Colors.grey);
                    }),
                  )),
              Container(
                margin: EdgeInsets.only(left: 10, right: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Center(
                      child: IconButton(
                        onPressed: () {
                          if (pageVal == 0) {
                          } else {
                            setState(() {
                              pageVal--;
                            });
                          }
                        },
                        icon: Icon(
                          Icons.arrow_back_ios,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Container(
                            child: Text(
                              data[1][defaultStep][pageVal]["desc"],
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                          AvatarGlow(
                            animate: _isListening,
                            glowColor: Theme.of(context).primaryColor,
                            endRadius: 75.0,
                            duration: const Duration(milliseconds: 2000),
                            repeatPauseDuration:
                                const Duration(milliseconds: 100),
                            repeat: true,
                            child: FloatingActionButton(
                              onPressed: () {
                                setState(() {
                                  _isListening = !_isListening;
                                  _listen();
                                });
                              },
                              child: Icon(
                                  _isListening ? Icons.mic : Icons.mic_none),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Center(
                      child: IconButton(
                        onPressed: () {
                          if (pageVal + 1 == data[1][defaultStep].length) {
                            if (defaultStep != data[1].length) {
                              setState(() {
                                defaultStep++;
                                pageVal = 0;
                              });
                            }
                          } else {
                            setState(() {
                              pageVal++;
                            });
                          }
                        },
                        icon: Icon(
                          Icons.arrow_forward_ios,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(20),
                height: 300,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage(
                          data[1][defaultStep][pageVal]["img"],
                        ))),
                width: MediaQuery.of(context).size.width,
              )
            ],
          ),
        ),
      ),
    );
  }
}
